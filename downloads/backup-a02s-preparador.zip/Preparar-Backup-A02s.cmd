@echo off
setlocal
title Preparar pasta Backup A02s
powershell.exe -NoProfile -Command "$ErrorActionPreference = 'Stop'; try { $taskDesktop = [Environment]::GetFolderPath('Desktop'); if ([string]::IsNullOrWhiteSpace($taskDesktop)) { throw 'Nao foi possivel localizar a Area de Trabalho.' }; $taskBackupRoot = Join-Path $taskDesktop 'Backup A02s'; New-Item -ItemType Directory -Force -Path $taskBackupRoot | Out-Null; foreach ($taskFolder in @('Arquivos', 'SmartSwitch', 'Cartao SD', 'WhatsApp')) { New-Item -ItemType Directory -Force -Path (Join-Path $taskBackupRoot $taskFolder) | Out-Null }; Write-Host 'Pasta preparada:'; Write-Host $taskBackupRoot; Write-Host 'Este preparador nao copia nem apaga arquivos do celular.'; Invoke-Item -LiteralPath $taskBackupRoot } catch { Write-Host ('Nao foi possivel preparar a pasta: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }"
if errorlevel 1 (
  echo Houve um erro. Leia a mensagem acima.
) else (
  echo Agora conecte o A02s e faca o backup pelo Samsung Smart Switch.
  echo Copie tambem o armazenamento interno para a subpasta Arquivos.
)
pause
